@include('partial.header')
        <main class="py-4">
            @yield('content')
        </main>
@include('partial.footer')
