@include('partial.header')
    
<div class="container-fluid">
    <div class="container">
        
    </div>
</div>

@include('partial.footer')