    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\table-reserver\resources\views/partial/footer.blade.php ENDPATH**/ ?>