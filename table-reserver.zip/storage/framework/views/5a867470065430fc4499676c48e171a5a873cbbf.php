<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">All Tables</div>
                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Seats</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($table->id); ?></td>
                                    <td><?php echo e($table->name); ?></td>
                                    <td><?php echo e($table->seats); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('deleteTable', $table->id)); ?>" method="POST">

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Create New Table</div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('storeTable')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">Name</label>
                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="seats" class="col-md-4 col-form-label text-md-right">Available Seats</label>
                                <div class="col-md-6">
                                    <input id="seats" type="number" class="form-control" name="seats" required>
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Create
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mb-5">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Reservations</div>
                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Table</th>
                                <th>Date</th>
                                <th>Time</th>
                            </tr>
                            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($reservation->id); ?></td>
                                    <td><?php echo e($reservation->user->name); ?></td>
                                    <td><?php echo e($reservation->table->name); ?></td>
                                    <td><?php echo e($reservation->date); ?></td>
                                    <td><?php echo e($reservation->time); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Create New Reservation</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('storeReservation')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="client" class="col-md-4 col-form-label text-md-right">Client</label>
                                <div class="col-md-6">
                                    <select name="user_id" id="client" class="form-control" required>
                                        <option value="">Please select a Client</option>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="table" class="col-md-4 col-form-label text-md-right">Table</label>
                                <div class="col-md-6">
                                    <select name="table_id" id="table" class="form-control" required>
                                        <option value="">Please select a Table</option>
                                        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($table->id); ?>"><?php echo e($table->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="table" class="col-md-4 col-form-label text-md-right">Date</label>
                                <div class="col-md-6">
                                    <input type="date" name="date" class="datepicker form-control" style="font-size: 12px">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="time" class="col-md-4 col-form-label text-md-right">Time</label>
                                <div class="col-md-6">
                                    <select name="time" id="time" class="form-control" required disabled>
                                        <option value="">Please select Time</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Create
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Change Operating Hours</div>
                    <div class="card-body">
                        <div class="row mb-4 text-center font-weight-bold">
                            <div class="col-md-3">Day</div>
                            <div class="col-md-2">Start</div>
                            <div class="col-md-2">Close</div>
                            <div class="col-md-2">Open</div>
                            <div class="col-md-3"></div>
                        </div>
                        <?php $__currentLoopData = $operatingHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operatingHour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form method="POST" action="<?php echo e(route('updateHours', $operatingHour->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <div class="col-md-3"><?php echo e($operatingHour->day); ?></div>
                                    <div class="col-md-2">
                                        <input id="starting_hour" type="number" class="form-control text-center" min="0" max="24" name="starting_hour" value="<?php echo e($operatingHour->starting_hour); ?>" />
                                    </div>
                                    <div class="col-md-2">
                                        <input id="closing_hour" type="number" name="closing_hour" min="0" max="24" class="form-control text-center" value="<?php echo e($operatingHour->closing_hour); ?>" />
                                    </div>
                                    <div class="col-md-2">
                                        <input id="open" type="checkbox" class="form-control" name="open" <?php echo e($operatingHour->open === true ? "checked" : ""); ?>/>
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" class="btn btn-primary">
                                            Update
                                        </button>
                                    </div>
                                </div>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $( document ).ready(function() {
            $('#table').change(function() {
                $('.datepicker').prop("disabled", false);
            })
            $(".datepicker").change(function(){
                var base_url = <?php echo json_encode(url('/')); ?>

                var value = $(".datepicker").val();

                var table = $('#table').val();

                $.ajax({url: base_url + "/reservations", data : { date: value, table: table }, success: function(result){
                        $('#time')
                            .find('option')
                            .remove()
                            .end()
                            .append('<option value="">Please select Time</option>')
                        for (key in result) {
                            var o = new Option(result[key], result[key]);
                            $(o).html(result[key]);
                            $("#time").append(o);
                        }
                        $('#time').prop("disabled", false);
                    }});

            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\table-reserver\resources\views/partial/adminDashboard.blade.php ENDPATH**/ ?>