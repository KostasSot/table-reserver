<h1>ADMIN</h1><?php /**PATH C:\xampp\htdocs\ticket-reserver\resources\views/partial/adminDashboard.blade.php ENDPATH**/ ?>
