    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ticket-reserver\resources\views/partial/footer.blade.php ENDPATH**/ ?>